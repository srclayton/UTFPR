package ecomerce;

public class EComerce {

    public static void main(String[] args) {
        Principal.executar();
    }
    
}
